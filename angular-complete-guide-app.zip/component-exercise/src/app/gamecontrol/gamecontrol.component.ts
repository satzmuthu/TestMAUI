import { Component, EventEmitter, Output } from '@angular/core';
import { interval } from 'rxjs';

@Component({
  selector: 'app-gamecontrol',
  templateUrl: './gamecontrol.component.html',
  styleUrls: ['./gamecontrol.component.css']
})
export class GamecontrolComponent {
  @Output() intervalFired = new EventEmitter<number>();
  lastNumber : number = 0;
  interval : any;

  onStartGame(){
    console.log('on start clicked');
       this.interval = setInterval(()=>{
        this.intervalFired.emit(this.lastNumber +1);
        this.lastNumber++;
       },1000);
      }

  onPauseGame(){
    clearInterval(this.interval)
  }
}
