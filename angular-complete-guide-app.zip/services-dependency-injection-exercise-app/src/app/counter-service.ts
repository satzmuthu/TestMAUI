export class CounterService{
    activeCounter : number =0;
    inactiveCounter : number =0;

    movedToActive(){
        this.activeCounter++;
        console.log("Total records moved to active :"+this.activeCounter);
    }

    movedToInactive(){
        this.inactiveCounter++;
        console.log("Total records moved to inactive :"+this.inactiveCounter);
    }
}