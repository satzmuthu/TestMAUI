import { Component, OnInit } from '@angular/core';
import { Recipe } from '../recipe.model';
import { RecipesServices } from '../recipes.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {

 recipe : Recipe = new Recipe();
 index: number =-1;
 constructor(private recipeService : RecipesServices, private route : ActivatedRoute, private router: Router){
     
 }
  ngOnInit(): void {
  // this.recipe = this.recipeService.getRecipe(+this.route.snapshot.params['id']) as Recipe;
   this.route.params.subscribe((params: Params) =>{
    this.index =+params['id'];
    this.recipe = this.recipeService.getRecipe(this.index) as Recipe;

   });
  }

  onEditRecipeClick(){
//this.router.navigate(['edit'], {relativeTo:this.route} );
this.router.navigate(['/recipes',this.index,this.recipe.name,'edit'] )
  }

 onAddToShoppingList(){
this.recipeService.addToShoppingList(this.recipe.ingredients);
 }

 onDeleteRecipe(){
  this.recipeService.deleteRecipe(this.index);
  this.router.navigate(['/recipes']);
 }
}
