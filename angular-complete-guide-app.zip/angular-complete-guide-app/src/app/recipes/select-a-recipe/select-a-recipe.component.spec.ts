import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectARecipeComponent } from './select-a-recipe.component';

describe('SelectARecipeComponent', () => {
  let component: SelectARecipeComponent;
  let fixture: ComponentFixture<SelectARecipeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SelectARecipeComponent]
    });
    fixture = TestBed.createComponent(SelectARecipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
