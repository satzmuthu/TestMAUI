import { Component } from '@angular/core';

@Component({
  selector: 'app-select-a-recipe',
  templateUrl: './select-a-recipe.component.html',
  styleUrls: ['./select-a-recipe.component.css']
})
export class SelectARecipeComponent {

}
