import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Ingredient } from 'src/app/shared/ingredient.model';
import { ShoppingListService } from '../shopping-list.service';
import { Form, NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit, OnDestroy {
 //@Output() ingredientAdded = new EventEmitter<Ingredient>();

 @ViewChild('f') slForm!: NgForm;
 startEditingSubscription! : Subscription;
 editMode : boolean = false;
 editedItemIndex : number =-1;
 editedItem! : Ingredient;

 constructor(private shoppingListService : ShoppingListService){
  
 }

 ngOnDestroy(): void {
  this.startEditingSubscription?.unsubscribe();
  }

  ngOnInit(): void {
    this.startEditingSubscription=  this.shoppingListService.startEditingItem.subscribe(
      (index : number)=>{
        this.editMode = true;
        this.editedItemIndex = index;
        this.editedItem = this.shoppingListService.getIngredient(index);
        this.slForm?.setValue({
          name : this.editedItem.name,
          amount: this.editedItem.amount
        });
      }
    );
  }

  onSubmitClick(form : NgForm){
    const formVal = form.value;
    const ingredient = new Ingredient(formVal.name, formVal.amount)
    if(this.editMode)
    {
     this.shoppingListService.updateIngredient(this.editedItemIndex, ingredient);
    }
    else
    {
    this.shoppingListService.addIngredient(ingredient);
    }

    this.editMode = false;
  this.slForm?.reset();

 //   this.ingredientAdded.emit();
  }

  onClearForm(){
  this.slForm?.reset();
  this.editMode = false;
  }

  onDelete(){
    this.shoppingListService.deleteIngredient(this.editedItemIndex);
    this.onClearForm();
  }
}
