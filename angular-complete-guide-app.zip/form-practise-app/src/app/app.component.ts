import { Component, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms'; 


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'form-practise-app';
  submitted = false;
  @ViewChild('f') form? : NgForm;
  defaultSubscription ="advanced";
  subscriptionDetails ={mail:"", subscription:"", password:""};

  OnSubmit(){
    if(this.form?.invalid)
    {
      this.submitted = false;
      alert("Form is invalid");
    }
    else
    {
      this.submitted = true;
      this.subscriptionDetails.mail = this.form?.value.mail;
      this.subscriptionDetails.password = this.form?.value.password;
      this.subscriptionDetails.subscription = this.form?.value.subscriptions; 
      //console.log(this.form?.value);
    }
  }
}
