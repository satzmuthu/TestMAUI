import { Component, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';
import { ServerElement } from '../shared/serverelement';


@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.css']
})
export class CockpitComponent {

 @Output() serverCreated = new EventEmitter<{serverName: string, serverContent: string}>();
 @Output('bpCreated') blueprintCreated = new EventEmitter<{serverName: string, serverContent: string}>();

 @ViewChild('serverContentInput') serverContentInput :any;
//  newServerName ='';
 // newServerContent ='';

  onAddServer(nameInput : HTMLInputElement){
     this.serverCreated.emit({ serverName: nameInput.value, serverContent: this.serverContentInput.nativeElement.value});
      }
    
      onAddBlueprint(nameInput : HTMLInputElement){
        this.blueprintCreated.emit({ serverName: nameInput.value, serverContent: this.serverContentInput.nativeElement.value});
   
        //   this.serverElements.push(new ServerElement(this.newServerName,'blueprint',this.newServerContent));
      }

}
