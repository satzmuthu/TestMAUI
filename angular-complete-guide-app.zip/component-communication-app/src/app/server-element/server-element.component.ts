import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, ContentChild, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild, ViewEncapsulation } from '@angular/core';
import { ServerElement } from '../shared/serverelement';
@Component({
  selector: 'app-server-element',
  templateUrl: './server-element.component.html',
  styleUrls: ['./server-element.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ServerElementComponent implements 
OnInit, 
OnChanges, 
DoCheck, 
AfterContentInit, 
AfterContentChecked, 
AfterViewInit, 
AfterViewChecked,
OnDestroy {

 @Input("serverElement") element:ServerElement= new ServerElement('','','');
 @Input() name:string ='';
 @ViewChild('headerElement') heading : any;
 @ContentChild('contentParagraph') paragraph : any;

  ngOnInit(): void {
  console.log("ngOnInit called.");
 }

 constructor(){
  console.log("constructor called.");
 }
  ngOnDestroy(): void {
    console.log("ngOnDestroy called.");
  }
  ngAfterViewChecked(): void {
    console.log("ngAfterViewChecked called.");
  }
  ngAfterViewInit(): void {
    console.log("ngAfterViewInit called.");
  console.log("Text content :"+ this.heading.nativeElement.textContent);

  }
  ngAfterContentChecked(): void {
    console.log("ngAfterContentChecked called.");
  console.log("Content paragraph content :"+ this.paragraph.nativeElement.textContent);

  }
  ngAfterContentInit(): void {
    console.log("ngAfterContentInit called.");
  }
  ngDoCheck(): void {
    console.log("ngDoCheck called.");
  }
  
 ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChanges called.");
    console.log(changes);
  }

}
