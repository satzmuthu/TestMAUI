import { Component } from '@angular/core';
import { ServerElement } from './shared/serverelement';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'component-communication-app';

    serverElements:ServerElement[]  =[new ServerElement('test server', 'server', 'test server content')];

    onServerCreated(serverCreatedData:{serverName: string, serverContent : string}){
       this.serverElements.push(new ServerElement(serverCreatedData.serverName,'server',serverCreatedData.serverContent));
         }
       
         onBlueprintCreated(blueprintCreatedData:{serverName: string, serverContent : string}){
           this.serverElements.push(new ServerElement(blueprintCreatedData.serverName,'blueprint',blueprintCreatedData.serverContent));
         }

         onClickChange(){
          this.serverElements[0].name="Changed!!!";
         }
   
         onDestroyFirst(){
          this.serverElements.splice(0,1);
         }

}


