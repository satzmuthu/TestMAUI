export class ServerElement{
    public name: string;
    public type: string;
    public content: string;
   
    constructor(name:string, type:string, content:string) {
      this.name = name;
      this.type= type;
      this.content = content;
    }
  
  }