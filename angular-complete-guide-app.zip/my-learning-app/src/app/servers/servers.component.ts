import { Component } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent {
  allowServer : boolean = false;
  serverCreationStatus: string ="No server created so far";
  serverName ='Test server';
  isServerCreated :boolean = false;
  servers =["Test server", "Test server1"];

   constructor (){
     setTimeout(()=>{ 
      this.allowServer = true;
     }, 2000);
   }

   setServerCreationStatus(){
    this.isServerCreated = true;
    this.servers.push(this.serverName);
   //this.serverName ="Test server 1"
   }

   updateServerName(event:Event){
    this.serverName=(<HTMLInputElement>event.target).value;

   }
}
