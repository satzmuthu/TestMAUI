import { Component, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @ViewChild('f') signupForm? : NgForm;
  defaultQuestion :string ='teacher';
  answer : string ='';
  genders =['Male', 'Female'];
  selectedGender ='Female';
  title = 'form-start-app';
  submitted =false;
  user = {userName:"", 
        email:"", 
        secretQuestion:"", 
        answer:"", 
        gender:""  
  };

  // onSubmit(form :NgForm){
  //   console.log(form);
  // }

  onSubmit(){
    this.submitted= true;
    this.user.userName = this.signupForm?.value.userGroup.username;
    this.user.email = this.signupForm?.value.userGroup.email;
    this.user.secretQuestion = this.signupForm?.value.secret;
    this.user.answer = this.signupForm?.value.questionAnswer;
    this.user.gender = this.signupForm?.value.gender;
    
    this.signupForm?.reset();
//console.log(this.signupForm);
  }

  suggestUserName(){
    const suggestUserName ='Super user';
    // this.signupForm?.setValue({
    //   "userGroup":{
    //     "username": suggestUserName,
    //     "email":""
    //   },
    //   "secret" :"pet",
    //   "questionAnswer":"",
    //   "gender":"Male"

    // });

    this.signupForm?.form.patchValue({"userGroup":{
      "username": suggestUserName
    }});
  }

}
