import { EventEmitter, Injectable } from "@angular/core";
import { LoggingService } from "./logging.service";

@Injectable()
export class AccountService{
    accounts =[{name:'Master account', status :'Active'}, {name:'Test account', status :'Inactive'}, {name:'Hidden account', status :'Unknown'} ];

    constructor(private loggingService: LoggingService){}
    
    statusUpdated = new EventEmitter<string>();

    addAccount(name: string, status : string){
        this.accounts.push({name: name,status: status});
        this.loggingService.logStatusChanged(status);
    }

    updateStatus(id: number, status: string){
        this.accounts[id].status = status;
        this.loggingService.logStatusChanged(status);
        this.statusUpdated?.emit(status);

    }
}
