import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'directive-pratice-app';
  isDetailsVisible = true;
  logs : Date[] =[];

  updateLog(){
    this.isDetailsVisible = !this.isDetailsVisible;
    this.logs.push(new Date());
  }

} 
